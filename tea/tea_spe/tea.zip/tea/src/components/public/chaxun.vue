<template>
  <div>
        <div class="chaxun">
          <span>|</span>
          <span>查询条件</span>
        </div>
  </div>
</template>
<script>
export default {
  name:'chaxun'
}
</script>
<style scoped>
 .chaxun {
text-align: left;
line-height: 50px;
color:#0068DC;
font-weight: 600;
font-size: 16px;
white-space: nowrap;
}
.chaxun span:first-child{
font-weight: 700;
font-size: 18px;
}
</style>


